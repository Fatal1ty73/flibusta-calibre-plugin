Calibre plugin for Flibusta OPDS
================================

Base url is https://flibusta.is so in Russia you should use VPN!
--


Installation:

Download it from [here](https://github.com/Fatal1ty73/flibusta-calibre-plugin/releases/tag/v1.0)

Go to: 

  ```Preferences > Advanced > Plugins > Load plugin from file```
  
Choose downloaded plugin zip archive.


